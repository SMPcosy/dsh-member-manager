# member-manager v0.1.2 · 安装 / 本地更新 / 上传说明

本归档目录结构：

```
dsh-plugin-member-manager/v0.1.2/
├── README.md                 版本总览
├── INSTALL-0.1.2.md          本文件
├── RELEASE-NOTES-0.1.2.md    发布说明（可直接贴 GitHub Release）
├── VERIFICATION-0.1.2.md     全面自检报告
├── SHA256SUMS-0.1.2.txt      本目录全部文件的校验和
├── artifacts/                ← 安装/上传用的产物在这里
└── patches/                  ← 相对 npm 0.1.1 的补丁
```

`artifacts/` 内文件：

| 文件 | 用途 | 大小 |
|---|---|---|
| `dsh-plugin-member-manager-0.1.2.tgz` | npm 兼容 tarball（根目录 `package/`），用于 **npm 发布** 或普通 npm 项目安装 | 166,762 B |
| `dsh-plugin-member-manager-0.1.2.zip` | 解压即得 `dsh-plugin-member-manager/` 目录，用于 **另一台电脑本地更新** | 185,023 B |
| `MANIFEST-0.1.2.txt` | 24 个文件的逐个 sha256 / 字节数 | 2,402 B |
| `SHA256SUMS.txt` | tgz / zip / manifest 的校验和 | 289 B |

---

## A. 另一台电脑本地更新（离线）

前置：目标机已装 DSH（desktop profile），且已装过 0.1.1 或更早版本。**不改数据格式**，`~/.dsh/storages/member-manager/registry.json` 原样兼容。

### A1. 校验并解压

```powershell
# 校验（与 SHA256SUMS.txt 里 zip 那一行比对）
Get-FileHash .\dsh-plugin-member-manager-0.1.2.zip -Algorithm SHA256

Expand-Archive .\dsh-plugin-member-manager-0.1.2.zip -DestinationPath .\unpacked -Force
```

### A2. 找到安装位置

```powershell
$dst = Join-Path $env:USERPROFILE '.dsh\profiles\desktop\node_modules\dsh-plugin-member-manager'
$dst
(Get-Item $dst).LinkType    # Junction = 链接安装；为空 = 真实目录
```

> 如果你用的是别的 profile 名，把 `desktop` 换成实际的 profile。

### A3. 替换（先看是哪种安装形态）

**情况 1：真实目录（LinkType 为空）**

```powershell
# 备份旧版；空间紧张可直接跳过备份
Copy-Item $dst "$dst.old" -Recurse -Force
Remove-Item $dst -Recurse -Force
Copy-Item .\unpacked\dsh-plugin-member-manager $dst -Recurse -Force
```

**情况 2：Junction / 链接（LinkType 为 Junction）**

```powershell
# 只删链接本身，不会删掉链接指向的源码
cmd /c rmdir "$dst"
Copy-Item .\unpacked\dsh-plugin-member-manager $dst -Recurse -Force
```

> 如果是 link 安装且你想继续维护源码目录：把解压出的 `dsh-plugin-member-manager\lib`、`src`、`locale`、`docs`、`test`、`package.json`、`README.md`、`LICENSE`、`icon.png`、`cordis.patch.yml` 覆盖到链接目标目录即可，不用动链接。

### A4. 完全退出 DSH 再启动

托盘里退出（不是只关窗口），再重新启动 DSH。客户端 bundle 与宿主代码都需要重启才会重新加载。

### A5. 验证

```powershell
# 1) 启动流水最后几行应出现 tools=12 / routes=6，且没有 failed
Get-Content "$env:USERPROFILE\.dsh\storages\member-manager\boot.log" -Tail 8

# 2) 版本应为 0.1.2
(Get-Content $dst\package.json -Raw | ConvertFrom-Json).version
```

3) 打开 DSH → Settings → **Member Manager**（或侧栏 👥）：
   - 成员编辑弹窗应该是一屏版：技能 / 模型并排两列，标题旁是蓝色高亮的「选择技能 / 选择模型」；
   - 点「选择模型」弹出可搜索的模型列表（按 provider 分组、显示 128k、有「使用默认（清除覆盖）」）；
   - 弹层开着按 Esc **只关弹层**。

### A6. 回滚

```powershell
Remove-Item $dst -Recurse -Force
Copy-Item "$dst.old" $dst -Recurse -Force   # 或把 .old 改名回原名
# 重启 DSH
```

---

## B. 上传更新（npm / GitHub）

本机现状：npm registry 上 `dsh-plugin-member-manager` 的 latest 是 **0.1.1**（2026-10-17 发布），本次已把包内版本升到 **0.1.2**。

### B1. 发布前校验（本机可做，不需要 npm）

```powershell
# 1) 包内单测（从 tarball 解出来跑，证明发布物自洽）
tar -xzf dsh-plugin-member-manager-0.1.2.tgz -C .\pubcheck
cd .\pubcheck\package
node --test test/*.test.mjs          # 期望 tests 134 / pass 134 / fail 0

# 2) 文件清单核对（应为 24 个文件，无 .bak / node_modules）
Get-Content ..\..\MANIFEST-0.1.2.txt
```

### B2. 发布到 npm

发布需要 npm（本机 DSH runtime 只带 pnpm，没有 npm；在任意装了 Node/npm 的机器上执行，或先登录 `npm login`）：

```bash
tar -xzf dsh-plugin-member-manager-0.1.2.tgz
cd package
npm publish --access public
```

- 包名非 scoped、`files` 白名单已就绪（`lib src locale docs test cordis.patch.yml icon.png` + 自动带上 `package.json / README.md / LICENSE`），共 24 个文件；
- 无任何 `dependencies` / `peerDependencies`，不会触发运行时依赖解析；
- `engines.node >= 22.19`（DSH runtime 自带 Node 满足）。

发布后验证：

```bash
npm view dsh-plugin-member-manager version     # 期望 0.1.2
npm view dsh-plugin-member-manager dist.tarball
```

### B3. GitHub Release

1. 打 tag：`v0.1.2`；
2. 上传 `dsh-plugin-member-manager-0.1.2.tgz`、`dsh-plugin-member-manager-0.1.2.zip`、`MANIFEST-0.1.2.txt`、`SHA256SUMS.txt`；
3. Release 正文直接用同目录的 `RELEASE-NOTES-0.1.2.md`。

### B4. 发布后

- 本机当前是「已改好的本地版」（版本号 0.1.2、代码与 Release 完全一致）；
- 若你之后想回到「纯 npm 版」，用 `npm i dsh-plugin-member-manager@0.1.2` 或插件市场更新替换即可；
- 目标机也可以用同样方式在线更新，不必再走 A 节的手工替换。

---

## C. 本次产物的校验值

见 `SHA256SUMS.txt`。tgz 与 zip 内的 `lib/client.js`、`lib/index.js` 与当前安装目录**逐字节一致**：

| 文件 | SHA256 |
|---|---|
| `lib/client.js` | `A52BD1A427A6D9A3ABCC92A1898A0D7B512E2FD5EB2664EA3DDAB1C9FDA29DCB` |
| `lib/index.js` | `3FE2FDB971FCCB2FF9A518F4B2F8E74B14710D215BF03CB14535E1061D6C0798` |
