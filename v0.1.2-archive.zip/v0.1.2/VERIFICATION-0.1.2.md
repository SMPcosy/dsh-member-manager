# member-manager 全面自检报告

- 日期：2026-10-19
- 对象：`C:\Users\rache\.dsh\profiles\desktop\node_modules\dsh-plugin-member-manager`（v0.1.1 + 本机改动）
- 口径：**只做自检 + 修明确缺陷**，不重构功能、不改数据格式
- 结论：**全绿**（134/134 单测、30/30 弹窗结构断言、61 项静态交叉审计 0 FAIL、两个补丁均可干净应用）

## 1. 自检方法（四层，互相独立）

| 层 | 手段 | 覆盖 |
|---|---|---|
| L1 语法/单测 | `node --check` + `node --test test/*.test.mjs` | 宿主 60 例（含 HTTP 路由）、registry-core/store、client bundle 30 例 |
| L2 结构断言 | `audit/member-manager/check-modal.mjs` | 真实渲染 `EditForm`，断言弹窗节点/尺寸/按钮/网格/无障碍回退 |
| L3 静态交叉审计 | `audit/member-manager/audit-static.mjs` | 编码、i18n 中英键集、`S.*`/`U.*` 引用完整性、死函数、hook 规则、op 白名单、视图字段、危险 API、路由表、补丁一致性 |
| L4 契约/补丁 | `override-contract.test.mjs`（`MM_PLUGIN_INDEX=<lib/index.js>`）+ `apply-patch-check.mjs` | 模型覆盖契约 6 例；client/index 两个补丁在 pristine 上重放后与安装文件逐字一致 |

命令：

```powershell
$node='C:\Users\rache\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe'
cd <pluginDir>; & $node --test test/*.test.mjs
cd audit\member-manager; & $node check-modal.mjs <plugin>\lib\client.js
& $node audit-static.mjs <plugin>
$env:MM_PLUGIN_INDEX='<plugin>\lib\index.js'; & $node --test override-contract.test.mjs
& $node apply-patch-check.mjs ..\..\dsh-plugin-member-manager\v0.1.2\patches\member-manager-client-modal-0.1.2.patch pristine\lib\client.js <plugin>\lib\client.js
& $node apply-patch-check.mjs ..\..\dsh-plugin-member-manager\v0.1.2\patches\member-manager-index-0.1.2.patch pristine\lib\index.js <plugin>\lib\index.js
```

## 2. 发现并修复的缺陷

### P1-1 宿主路由没有兜底，写盘失败被当成「你填错了」

- 现象：`/op` 直接 `fn(...)`，`service` 内部把一切异常折成 `{ok:false, code:"INTERNAL_ERROR"}`；路由再统一映射 400。磁盘写不进去（EPERM/ENOTDIR/ENOSPC）时，面板会显示「操作失败 + 400」，用户以为是自己填错。
- 修复：`lib/index.js`
  - `route()` 统一包一层 `async guarded`：handler 抛错 → `500 {code:"INTERNAL"}` + `bootMark("route-threw:…")` + `routeState.errors` 记录，且不会向 webServer 抛异常；
  - `/op` 改 `await fn(...)`（未来异步 service 不会漏 catch），并按 code 分级：`INTERNAL_ERROR`/`INTERNAL` → 500，其余业务错误 → 400；
  - `/health` 补 method 校验（与其它路由一致）。
- 验证：新增 2 例宿主测试（写盘点被占成目录 → 500 `INTERNAL_ERROR`；未知 op 仍 400 `UNKNOWN_OP`）。

### P1-2 弹层开着时按 Esc 会把整张表单关掉

- 现象：`EditForm` 的 keydown 直接 `onCancel()`。用户在模型弹层里挑完还没点「完成」，一按 Esc 表单和选择一起没了。
- 修复：Esc 优先关子弹层（`picking` → `pickingModel` → 才 `onCancel`），依赖数组补 `picking/pickingModel`。
- 验证：新增 client 测试（注入 `window.addEventListener` 捕获监听 + spy setter，断言 Esc 只触发 `setPicking(false)`、不触发 `onCancel`）。

### P2-1 保存部分成功时界面不回读

- 现象：保存 = renameMember → setRole → setSkills → setModel 四个串行请求；中途失败时前面几条已落盘，界面仍显示旧数据且只报一个错。
- 修复：`saveDraft` 的 catch 里先 `await load()` 回读真实名册，再显示错误。

### P2-2 中文显示名为空也能点保存

- 现象：宿主 `requireText` 必然抛 `EMPTY_FIELD`，用户点了才知道。
- 修复：`canSave = !busy && draft.displayName.trim()`，保存按钮 `disabled: !canSave` + `title` 提示；新增文案 `displayNameRequired`（zh/en）。
- 验证：新增 client 测试（空/纯空格 → 禁用；填了 → 可点）。

### P2-3 保存请求在飞时可用遮罩关窗

- 修复：`S.modal` 的 `onClick` 加 `if (busy) return;`（请求未完成时不允许点遮罩关闭）。

### P3 清理死代码

- 文案键：删除未使用的 `skills`、`modelPick`（zh/en 同步）。
- 样式键：删除未引用的 `btnDanger`、`btnOn`、`count`、`row2`。
- 修正 `EditForm` 里关于「模型下拉」的过期注释。

## 3. 审阅结论（未改动但已逐段核对）

- `src/shared/registry-core.mjs`：所有写操作纯函数 + `clone`，校验完整（`requireTarget/requireText/requireStringList`、`AMBIGUOUS_SKILLS`、`NOTHING_TO_UPDATE`、孤立 provider 清除逻辑正确）。
- `src/shared/registry-store.mjs`：tmp 文件 + `fsync` + `rename` 原子写、写前 `.bak`、坏 JSON 隔离到 `quarantine/`、读失败回退空名册（不抛）。唯一约束：只保留一份 `.bak`（文档已声明）。
- `src/shared/team-service.mjs`：`#run` 统一把 `RegistryError` → `{ok:false,code}`，其它异常 → `INTERNAL_ERROR`；`onWrite` 精确失效宿主缓存。
- `lib/index.js` 模型覆盖：按 `agent.ctx`（而不是 agent.id）去重、`WeakSet` 防重复挂载、`agent/request` 水位改写、`system-prompt/assemble` 同步变量、审计环上限 50 条、失败静默降级。设计正确。
- 客户端：hook 全部无条件调用；`MemberRow` 的 `onAssign` 已把空串转 `null`；无 `dangerouslySetInnerHTML/eval/innerHTML`；`<form>` 不存在（按钮不会误提交）。

## 4. 未修的已知项（记录在案，非本次范围）

1. **WARN**：宿主 op `renameGroup` 面板无入口（可建组/删组/改组，不能改名）。属功能缺口，不是缺陷。
2. HTTP 路由无独立鉴权，依赖 DSH webServer 的会话鉴权（未登录实测 401）；若未来 webServer 暴露到非本机需重新评估。
3. `docs/00~07` 仍是 v0.1.1 的 UI 描述，未随这几次界面改版更新；当前以 `patches/CHANGES-member-manager.md` 为准。
4. 保存仍是 4 个非事务请求（已做失败回读，但做不到真正原子）。
5. `.bak` 仅一份，连续两次写失败可能丢掉两次前的快照。

## 5. 最终一致性

- 安装目录：`lib/client.js` 66,694 B / SHA256 `A52BD1A4…`；`lib/index.js` 55,240 B / SHA256 `3FE2FDB9…`
- 单测：**134/134**（新增 4 例：宿主 2、客户端 2）
- 弹窗结构：**30/30**
- 静态审计：**61 项，PASS 58 / WARN 3 / FAIL 0**
- 覆盖契约：**6/6**
- 补丁（位于 `dsh-plugin-member-manager/v0.1.2/patches/`）：
  - `member-manager-client-modal-0.1.2.patch` → **23 hunk / +692 −165**，重放与安装文件逐字一致
  - `member-manager-index-0.1.2.patch` → **10 hunk / +111 −17**，同上
- `audit/patched/lib/{client,index}.js`、`audit/patched/test/*` 已与安装目录同步
