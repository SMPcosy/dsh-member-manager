# dsh-plugin-member-manager v0.1.2

发布日期：2026-10-19
包名 / 版本：`dsh-plugin-member-manager@0.1.2`
变更范围：**Web 面板（编辑弹窗 + 模型选择）与宿主 HTTP 健壮性**；数据结构与名册文件格式不变。

## 亮点

- 🖥️ **编辑弹窗重排，一屏放下**
  - 技能 / 模型并排成两列（省掉约 170px 纵向高度）；
  - 职责文本域 132 → 88px（仍可手动拉高），分组间距 / 页头 / 页脚收紧；
  - 实测面板高约 580px，`1280×740` 视口下「取消 / 保存」完整可见。
- 🔵 **「选择技能 / 选择模型」改为高亮胶囊按钮**，从分组行最右端挪到分组标题紧右侧。
- 🧠 **模型选择改为弹层**（与技能弹层同一套外观与交互）
  - 可搜索（provider / 模型 id）；
  - 按 provider 分组，显示上下文窗口（如 `128k`）；
  - 单选 radio，首项固定「使用默认（清除覆盖）」；
  - 底部「共 N 个模型 + 完成」；选中后同时写入 provider + model；
  - 目录外的 id 仍可在下方手填。
- 🛡️ **宿主更健壮**
  - 所有 HTTP 路由统一兜底：handler 抛错返回 `500 {code:"INTERNAL"}` 并写 `boot.log`（`route-threw:…`），不再把异常抛给 webServer；
  - 写盘失败（EPERM/ENOTDIR/ENOSPC）映射为 **500 + `INTERNAL_ERROR`**，不再伪装成 400「你填错了」；
  - `/op` 以 `await` 调用 service（兼容未来异步实现）；`/health` 补 method 校验。
- ⌨️ **交互修复**
  - 弹层开着时 Esc **先关弹层**，不会把整张表单一起关掉；
  - 保存请求进行中不响应遮罩点击；
  - 中文显示名为空时禁用保存（宿主 `requireText` 必拒空值）；
  - 保存部分成功（4 个串行 op 中途失败）会自动回读真实状态。
- 🧹 **清理**：删除未使用的文案键（`skills` / `modelPick`）与样式键（`btnDanger` / `btnOn` / `count` / `row2`）；修正过期注释。

## 验证

| 项 | 结果 |
|---|---|
| 单元 / 集成测试 | **134/134**（0.1.1 为 130，本次新增宿主 2 例、客户端 2 例） |
| 弹窗结构断言（真实渲染 EditForm） | **30/30** |
| 静态交叉审计（编码 / i18n 键集 / 样式引用 / 死代码 / hook 规则 / op 白名单 / 视图字段 / 危险 API / 路由 / 补丁一致性） | **61 项：PASS 58 / WARN 3 / FAIL 0** |
| 模型覆盖契约测试 | **6/6** |
| tarball 解包后自测 | **134/134** |

3 个 WARN 均非缺陷：`renameGroup` 宿主有 op 但面板无入口（功能缺口）、`docs/00~07` 未随 UI 更新、HTTP 路由依赖 DSH webSession 鉴权（未登录实测 401）。

## 兼容性

- 数据结构：**不变**。`~/.dsh/storages/member-manager/registry.json` 直接沿用，无迁移。
- 运行时：Node >= 22.19；在 DSH desktop profile / 运行时 `0.2.0-rc.2` 上验证。
- 依赖：无 `dependencies` / `peerDependencies`。
- **升级后需完全退出并重启 DSH**（客户端 bundle 与宿主代码都会重新加载）。

## 安装 / 升级

- npm：`npm i dsh-plugin-member-manager@0.1.2`
- 离线：解压 `dsh-plugin-member-manager-0.1.2.zip`，用 `dsh-plugin-member-manager/` 覆盖 profile 的 `node_modules/dsh-plugin-member-manager`，重启 DSH（详见 `INSTALL-0.1.2.md`）。

## 产物与校验

| 产物 | 大小 | SHA256 |
|---|---|---|
| `dsh-plugin-member-manager-0.1.2.tgz` | 166,762 B | `d626e17fb3b1880018ed6549ea5bdb14405f8203a038cc026d6b9d1b638c9159` |
| `dsh-plugin-member-manager-0.1.2.zip` | 185,023 B | `8427238afa70c183d90f9753d8f6286a9950e1392f723dd97df3b0b24085534b` |

包内 24 个文件；`lib/client.js` SHA256 `A52BD1A4…`，`lib/index.js` SHA256 `3FE2FDB9…`，与本地验证通过的版本逐字节一致。产物校验和同时记录在 `artifacts/SHA256SUMS.txt` 与 `SHA256SUMS-0.1.2.txt`。

## 已知问题（不阻塞发布）

1. 面板没有「小组改名」入口（宿主已有 `renameGroup` op，可通过工具/后续版本补齐 UI）；
2. `docs/00~07` 仍是 v0.1.1 时期的需求/设计文档，界面细节以 README 的 v0.1.2 更新要点与本文为准；
3. 保存仍是 4 个非事务请求（已做失败回读，但非原子）。
