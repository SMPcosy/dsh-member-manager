# member-manager 本地补丁变更说明（供 0.1.2 合并）

- **基线**：`dsh-plugin-member-manager@0.1.1`（npm 发布版）
- **变更包**：`patches/member-manager-0.1.1-local.patch`（7 个 hunk，+82 / −13 行，只动 `lib/index.js`）
- **验证**：包内 130/130 通过；新增契约测试 6/6 通过（原版同测试 2/6）
- **建议版本号**：`0.2.0`（新增导出字段 `history`、新增字段 `installedInstances`，超出 patch 语义）

## 一、三处代码改动

### 1. 幂等键从 `agent.id` 改为作用域 `ctx`

**问题**：`Set<agent.id>` 去重会漏装——可续接成员在后续轮次会换一个新的 agent 实例（同 id、新对象），钩子只挂在首轮实例上，**第二轮起静默回落到默认模型，且无任何报错**。

**另外**：若 `agent/created` 与 `agent/status` 用不同包装对象、同一 ctx 送出，按对象去重会**双装钩子**（覆盖应用两次、审计双计、系统提示改写两次）。

**改法**：`WeakSet<ctx>`，键取 `agent.ctx`。

**对应测试**：A3（同 id 新实例必须重装）、A4（同 ctx 双包装只装一次）。

### 2. 新增覆盖审计 `history`

**问题**：原先只有 `applied / misses / lastApplied`，事故复盘无法回答「这次到底改了什么」。

**改法**：`overrideStats.history`，环形保留最近 50 条，每条形如：

```js
{
  at, agentInstanceId, target, source: "roster",
  before: { provider, model, reasoningEffort? },
  after:  { provider, model, reasoningEffort? },
  result: "applied", code: null
}
```

暴露面：`GET /overrides`（`data.history`）与 `member_diagnose`（`modelOverride.history`），各取最近 20 条。

**对应测试**：F5。

### 3. 新增错误诊断钩子

**问题**：覆盖后的请求若在 `prepareCall` 阶段失败（例如目标模型不支持所带推理强度），会话里没有痕迹，只能靠猜。

**改法**：监听 `agent/request-error` 与 `agent/error`，把 `code + message` 写入 `bootMark`。

**对应测试**：诊断钩子。

## 二、对外字段：改名 + 兼容别名

| 入口 | 新字段 | 兼容旧字段 |
|---|---|---|
| `GET /overrides` | `installedInstances` | `installedCount`（继续输出） |
| `member_diagnose.modelOverride` | `installedInstances` | `installedAgents`（继续输出） |

**为什么保留旧名**：0.1.1 的包内测试断言的是旧字段（`test/host-plugin.test.mjs:1253`、`:1293`），改名会让 130 个测试挂 2 个。保留别名可让升级无痛。

**建议**：在 README/CHANGELOG 里标注旧名 `deprecated`，下个 minor 再移除；同时把包内那两条断言改成新字段名。

> 注意：`installedInstances` 是**累计安装次数**（续接每轮 +1），不等于「当前生效成员数」。若要 live 口径，需另加 `WeakRef` 集合维护。

## 三、新增测试（建议并入包内）

`audit/member-manager/override-contract.test.mjs`，6 个用例，只用最小 ctx 替身，不依赖 DSH 运行时：

| 用例 | 原版 | 补丁版 |
|---|---|---|
| F1 只改白名单字段 | ✅ | ✅ |
| F2 云端覆盖保留 reasoningEffort | ✅ | ✅ |
| A3 同 id 新实例重装钩子 | ❌ | ✅ |
| F5 审计含 before/after | ❌ | ✅ |
| 诊断钩子存在 | ❌ | ✅ |
| A4 同 ctx 双包装只装一次 | ❌ | ✅ |

建议放到 `test/override-contract.test.mjs` 并加入 `package.json` 的 `test` 脚本。原版失败的三项恰好证明：**包内 130 个测试全绿并不覆盖关键路径**。

## 四、使用侧前提（不是插件代码，但值得写进文档）

本地模型路由必须在 DSH 配置里**声明 `reasoningEfforts`**，否则当成员被覆盖到该模型、而请求携带 `reasoningEffort` 时，`dsh-llm` 会在任何网络 I/O 之前拒绝：

```
UNSUPPORTED_REASONING_EFFORT: pi-ai provider "ollama" model "qwen3.5-64k" does not support reasoning effort "high"
```

这不是插件的错，但排查时极易误判为「插件坏了」。建议在 README 的「模型覆盖」小节加一句说明。

## 五、本次未纳入（建议下一版）

1. 审计落盘（目前内存 50 条，重启即丢）
2. 启动自检/版本哨兵（补丁失效或接缝变更不可见）
3. `bootMark` 改为追加写 + 轮转（现在是整文件重写，O(n) 同步 I/O，多 profile 会互相覆盖）
4. `lastApplied.agentId` 与 `history.agentInstanceId` 命名统一
5. 工具调用能力进配置声明（目前 `deepseek-r1` 这类「有档位但无工具」的模型只能靠人工台账拦截）

## 六、如何应用

```powershell
cd <repo>
git apply --check ..\patches\member-manager-0.1.1-local.patch   # 先校验
git apply ..\patches\member-manager-0.1.1-local.patch
node --test test/*.test.mjs
```

补丁内中文注释可随仓库风格改写，逻辑不受影响。

---

# 追加变更：编辑面板改为弹窗

- **变更包**：`patches/member-manager-client-modal.patch`（含后续「再放大」「版式重排」，11 个 hunk，+209 / −28，只动 `lib/client.js`）
- **问题**：编辑表单原先内嵌在页面顶部（列表上方）。成员多、页面长时，点下方成员的「编辑」，表单出现在页顶，用户必须滚回上去才看得见。
- **改法**：改为 `position: fixed` 的模态弹窗，居中显示在当前视口，不随页面滚动位置变化。

## 具体改动

1. **新增两个样式**：`S.modal`（固定定位、`inset: 0`、半透明遮罩、`z-index` 拉高）与 `S.modalPanel`（`min(620px, 100%)` 宽、`maxHeight: 85vh` 可滚动、圆角与投影）。
   面板底色用系统色 `Canvas` / `CanvasText`，随浅色/深色主题自动适配，不写死颜色。
2. **渲染位置**：`draft` 存在时不再内嵌渲染 `EditForm`，而是用遮罩包住面板渲染。
3. **关闭方式**：点遮罩空白处（`e.target === e.currentTarget`）或按 `Esc` 关闭。
4. **去掉重复边框**：`EditForm` 新增 `plain` 属性，弹窗内传入 `plain: true`，避免「面板边框 + 表单边框」双层。
5. **测试环境守卫**：`Esc` 监听前检查 `typeof window !== "undefined"`，否则在无 DOM 的测试环境渲染 `EditForm` 会直接抛错。

## 验证

- 包内 130 个测试全绿（改动过程中曾有 2 个客户端用例因 `window` 未定义失败，已由第 5 条修复）
- 结构自检 10/10 通过（`audit/member-manager/check-modal.mjs`）：模块可求值、`Panel`/`EditForm` 仍导出、遮罩 `position: fixed`、`inset: 0`、面板 `maxHeight: 85vh`、`draft` 走弹窗分支、`plain` 生效、`Esc` 守卫存在、点遮罩关闭逻辑存在

**视觉与交互仍需在真实页面确认**（无浏览器环境下只能做到结构级验证）。客户端 bundle 变更需要重启 DSH 才会被重新下发。

---

# 追加变更：编辑弹窗再放大（尺寸 + 字号）

- **变更包**：同上 `patches/member-manager-client-modal.patch`（最终合并后 11 个 hunk，+209 / −28）
- **问题**：弹窗改出来后仍是 620px 宽、85vh 高，字段是页面级小字号（label 11.5px、input 12.5px），成员信息一多就显得局促。

## 具体改动

1. **面板放大**：`width` `min(620px, 100%)` → `min(900px, 100%)`；`maxHeight` `85vh` → `90vh`；`padding` 14 → 22；圆角 10 → 12。
2. **弹窗专用大号控件**（新增 `S.titleLg / fieldLg / labelLg / inputLg / taLg / btnLg / btnPrimaryLg / headLg / gridLg / footerLg` 等）：
   - 输入框：内边距 `5px 8px` → `8px 10px`，字号 12.5 → 14
   - 职责文本域：`minHeight` 56 → 132，字号 14，`resize: vertical`（可手动拉高）
   - label 11.5 → 12.5，字段间距 8 → 14，双列间距 10 → 16
   - 按钮：`5px 10px`/12px → `8px 16px`/13.5px
   - 标题 13 → 18（后一版版式重排又微调），技能标签内边距与字号同步放大
3. **尺寸按场景切换**：新增 `FORM_SM` / `FORM_LG` 两组样式，`EditForm` 内 `const U = plain ? FORM_LG : FORM_SM`。只有弹窗（`plain: true`）用大号，页面里内嵌的「新建分组」等表单保持原尺寸，**不复制两份表单逻辑**。
4. 模型下拉与手填输入框之间的间距 4 → 6，避免大字号下贴得太近。

## 验证

- 包内 130/130 测试通过（`EditForm` 不带 `plain` 时走 `FORM_SM`，原有用例不受影响）
- 结构自检升级为 13/13（`audit/member-manager/check-modal.mjs`）：新增「面板放宽到 900px」「面板高限 90vh」「大号输入/文本域样式存在」「EditForm 按 plain 选尺寸」四项
- 补丁已由 `audit/member-manager/make-diff.mjs` 对 `pristine/lib/client.js` 重新生成，`git apply --check` 前建议先在干净基线校验

**客户端 bundle 变更需重启 DSH 后重新打开成员编辑弹窗生效。**

---

# 追加变更：编辑弹窗版式重排（文本结构 / 栏目对齐 / 按钮布置）

- **变更包**：同上 `patches/member-manager-client-modal.patch`（最终 11 个 hunk，+209 / −28）
- **问题**：放大只解决了「尺寸」，信息仍是平铺的一串字段——标题只有一个「编辑：lead」、没有分组；「模型」那一行左边是下拉、右边是 provider，而模型 id 输入框掉到下一行，右列下方常年留一块空白；保存/取消挤在左下角，和表单读序（从上到下、从右到左收尾）相反。

## 具体改动

1. **标题区**：`h2`「编辑成员」+ 副标题「成员标识（等宽字体）+ 启用中/已停用徽章」。`target` 从正文标题里挪到副标题，正文不再重复。徽章数据来自 `onEdit` 新带的 `draft.isRetired`（**仅展示，不参与保存**）。
2. **四个分组，结构统一**：基本信息 / 岗位职责 / 技能 / 模型。每组上方一条细分隔线，组名左侧一条 3px 蓝色强调条；「每行一条」这类补充说明降为淡色小字（新增 `S.aside`），不再和组名同权重。
3. **两列网格对齐**：基本信息与模型两组改用 `display: grid; gridTemplateColumns: 1fr 1fr`，每个格子固定「label + 控件」，两列逐格对齐，不再用 `flex: 1 / flex: 2` 手工配比。
4. **模型组重排**（修错位）：整行下拉做快捷选择 → 下方两列「模型 id | Provider」。之前 provider 与下拉同一行、模型 id 掉到下一行，右列下方留空；现在三个控件各归其位。
5. **技能组**：组名行右侧放「选择技能」按钮，下方依次是已选标签行、自定义标签输入框。
6. **底部操作栏**：左侧「按 Esc 或点击空白处关闭」提示（`margin-right: auto` 推开），右侧「取消 → 保存」，主按钮（蓝底）靠最右，符合收尾习惯。
7. **i18n 同步**：新增 `editTitle / basicInfo / dutiesHint / skillsSection / modelSection / closeHint / statusActive / statusRetired`，中英字典都补齐；`duties` 拆成标题 + `dutiesHint`。

## 验证

- 包内 130/130 测试通过（`EditForm` 的按钮标签、输入框取值、技能标签等用例均不受结构影响）
- 结构自检升级为 **23/23**（`audit/member-manager/check-modal.mjs`）：新增真渲染断言——标题为独立 `h2`、四个分组强调条、两个两列网格、「网格内 label 与控件逐格对齐」、底部「提示 + 取消 + 保存」且保存为主色按钮
- 新增离线预览链：`preview-modal.mjs` 用同一份 `client.js` 的 `S` 样式渲染 `EditForm(plain)` → HTML → 无头 Edge 截图（`preview-modal.png`），改版式后可一键出对比图
- 补丁已重新生成（11 hunk / +209 −28），`patched/lib/client.js` 与安装目录文件哈希一致

**客户端 bundle 变更需重启 DSH 后重新打开成员编辑弹窗生效。**

---

# 追加变更：主界面（成员列表页）排版重排

- **变更包**：同上 `patches/member-manager-client-modal.patch`（并入本文档所有客户端改动后，合计 **20 个 hunk，+442 / −110**，仍只动 `lib/client.js`）
- **问题**：主面板是「标题 + 一行操作按钮 + 一行页签 + 卡片」四层堆叠——
  1. 操作按钮（刷新 / 同步 / 新建小组）与页签按钮**同一套外观**，视觉层级分不清哪排是「动作」、哪排是「切换」；
  2. 统计信息 `共 8 人 · 启用 7 …` 是一行 11px 淡字，被挤在工具栏最右端，几乎读不到；
  3. 表头写的是输入框用语「技能（逗号分隔）」，最后一列表头为空；
  4. 小组下拉固定 130px，把「操作」列挤到 10%，**编辑/停用两个按钮被迫上下换行**；
  5. 卡片有 12px 内边距，表格浮在卡片中间，边框与表头不贴边；
  6. 空态/未登记页直接裸文本，没有留白与容器。

## 具体改动

1. **页头分区**（新增 `S.head / titleBlock / statsRow / statChip / statNum / actions`）：左侧「标题 18px + 副标题 + 四个统计胶囊」，右侧操作按钮组。统计从一行长句拆成 `成员 8` `启用 7` `停用 1` `小组 2` 四个胶囊，数字加粗；完整汇总句仍保留在容器的 `title` 属性里做悬停提示（不丢信息）。
2. **页签改分段控件**（`S.tabs / tab / tabOn / tabCount`）：浅底圆角容器 + 选中项用 `Canvas` 色「浮起」+ 计数小字，跟右侧实心蓝主按钮形成明确层级，不再是两排一样的按钮。
3. **卡片改「表头条 + 贴边表格」**（`S.card / cardHead / countPill / cardDesc`）：卡片去掉内边距、`overflow: hidden`，表头行做成有底色的条；组名 + 人数胶囊 + 次要描述（单行省略）；「移除」从描边红按钮降为**无边框文字危险按钮**（`S.btnGhostDanger`），不再抢视线。
4. **表格定宽**（`S.table` 加 `tableLayout: fixed` + `colgroup` 五列：28% / 25% / 20% / 13% / 14%）：列宽不再随内容长短跳动；空表头改为 `操作`。
5. **表头语义修正**：技能列表头用「技能」（`skillsSection`），不再是输入框提示语；新增 i18n `actions`。
6. **行内控件收小**：小组下拉改 `S.selectSm`（吃满列宽、字号 12、无背景），操作列改右对齐小按钮（`rowActions / btnSm / btnSmDanger`），**编辑 + 停用同一行**；停用态显示「恢复」。
7. **名称列信息分层**：中文名（600）→ target（等宽 11.5px）→ 模型徽标（`S.modelTag`，单行省略、provider 放 tooltip）→「当前会话未列出」琥珀色徽章从技能列挪到名称列（它说的是归属，不是技能）。
8. **职责列**：`ul` 去项目符号、改用 `· ` 前缀逐行淡色显示，行高 1.55，比默认圆点列表更贴表格。
9. **最后一行去底边**（`MemberRow` 新增 `last` 属性传 `borderBottom: none`），避免「行分隔线 + 卡片边框」双线。
10. **未登记 / 已停用页重排**：都套同一张 `S.card`，表头条带计数与说明；未登记页每行「target + 登记按钮」右对齐，底部「全部登记」主按钮；已停用页空态显示 `—`。
11. **空态**（`S.emptyBox`）：居中、22px 纵向留白，不再是左上角一行小字。
12. **新建小组表单**：名称/说明两列并排（`flex: 1; minWidth: 200`），底部按钮右对齐「取消 → 创建」。
13. **i18n 新增**：中英各补 `statMembers / statActive / statRetired / statGroups / actions`。

## 验证

- 包内 **130/130** 测试通过；`MemberRow` 的模型徽标用例（断言 `模型: xxx`）与小组移除、未登记登记、错误兜底等用例均未受影响
- 结构自检 `check-modal.mjs` **23/23** 仍通过（弹窗部分未动）
- **新增离线预览链**（无浏览器、无 DSH 运行即可出图）：
  - `audit/member-manager/preview-lib.mjs`：抽出「加载真实 bundle / 抽取 `S` 与 `zh` 字面量 / 序列化元素树」公共件，按需调用函数组件
  - `audit/member-manager/preview-panel.mjs`：用预置 state 渲染 `Panel`，支持 `org / retired / unregistered / groupform / empty / core-off / editmodal` 七个场景
  - `audit/member-manager/preview-modal.mjs` 同步改为复用 `preview-lib.mjs`
  - 截图：`preview-panel-org.png`、`preview-panel-groupform.png`、`preview-panel-unregistered.png`、`preview-panel-retired.png`、`preview-panel-empty.png`、`preview-panel-core-off.png`、`preview-panel-editmodal.png`
- 补丁重新生成并校验：`make-diff.mjs` → 20 hunk / +442 −110；`apply-patch-check.mjs` 在 `pristine/lib/client.js` 上应用后**与安装文件逐字一致**（53,931 字符）；`patched/lib/client.js` 与安装目录 SHA256 相同

**客户端 bundle 变更需重启 DSH 后重新打开「成员管理」页生效。**

---

# 追加变更：编辑弹窗再收紧（一屏内 / 技能按钮高亮 / 模型选择弹层）

- **变更包**：同上 `patches/member-manager-client-modal.patch`（并入后合计 **22 个 hunk，+671 / −159**，仍只动 `lib/client.js`）
- **问题**：
  1. 弹窗内容高约 745px，在 800px 以下的窗口里会被 `90vh` 截断，必须滚动才能看到「保存」；
  2. 「选择技能」放在分组标题行最右端，是普通描边按钮，离标题很远，既弱又远；
  3. 模型是原生下拉，宽度吃满整行，交互与技能（弹层多选）不一致。

## 具体改动

1. **压到一屏**：职责文本域 `minHeight` 132 → 88（仍可手动拉高）、分组间距 `20/16` → `14/12`、字段行距 14 → 10、面板内边距 22 → 18、页头/底部操作栏间距收紧。实测面板高约 **580px**，`1280×740` 视口下「取消 / 保存」完整可见。
2. **技能 / 模型并排两列**（新增 `S.duoLg`，`1fr 1fr` + `columnGap: 20`）：两段内容各占一半宽度，省掉约 170px 纵向高度——这是「一屏放下」的关键一步。
3. **「选择技能」高亮并贴近标题**：新增 `S.pickLg`（蓝字 + 淡蓝底 `rgba(47,111,235,.12)` + 蓝边 + 圆角胶囊）；`sectionHead` 的右侧操作从 `marginLeft: "auto"` 改为 `marginLeft: 6`，按钮紧贴分组标题。
4. **模型选择改弹层**：新增 `ModelPicker`，与 `SkillPicker` 同一套外观与交互——搜索框、按 provider 分组、显示 `contextWindow`（如 `128k`）、单选 radio、首项「使用默认（清除覆盖）」，底部「共 N 个模型 + 完成」。目录外的 id 仍可在下方手填 provider/model。
5. **模型当前值**：等宽字体显示 `provider · model`，右侧「清除」文字按钮一键清空覆盖。
6. **两个弹层共用样式**（`S.pickerBox / pickerCard / pickerHead / pickerSearch / pickerList / pickerFoot / pickerRow ...`），`SkillPicker` 同步改用共享样式（原来硬编码 `#fff`，深色主题下会和面板脱色）；底色改用 `Canvas / CanvasText` 跟随主题。
7. **i18n 新增**：`pickModel / searchModels / noModels / modelTotal / useDefault / modelHint / clear`（zh + en）。

## 测试与验证

- 包内 **130/130** 通过；其中 **1 条用例改写**（`test/client-bundle.test.mjs`）：原「模型下拉从 /models 拉取选项，选中后同时写入 provider 与 model」→「模型选择改为弹层，从 /models 拉目录并一次写入 provider 与 model」，断言从「1 个 select」改为「无 select + 点按钮挂载 ModelPicker + radio 回调写 provider/model」。
- 结构自检 `check-modal.mjs` 升级为 **27/27**：新增 `ModelPicker 已导出`、`技能与模型并排两列`、`模型选择改为弹层（无原生下拉）`、`「选择技能 / 选择模型」高亮胶囊按钮`、`两个按钮紧贴分组标题`、`职责文本域压到 88px`。
- 预览链扩展：`preview-modal.mjs` 支持 `form / model / skill` 三种模式，新增截图：
  - `preview-modal-form-1280x740.png`（**一屏验证**：740px 视口下整张表单完整可见）
  - `preview-modal-model.png`（模型弹层）
  - `preview-modal-skill.png`（技能弹层，用于对比两者外观）
- 补丁重新生成：**22 hunk / +671 −159**；`apply-patch-check.mjs` 在 pristine 上应用后与安装文件逐字一致（61,854 字符）；`patched/lib/client.js` 与安装目录 SHA256 相同（`D9B49629…`）。

> 注：上面这组数字是本节当时状态。下一节「全面自检」修了 5 处缺陷并新增测试，**最终数字以自检节为准**（client 23 hunk / +692 −165，单测 134/134）。

---

# 追加变更：全面自检与缺陷修复（2026-10-19）

- **范围**：全量静态审计 + 四层验证 + 修复明确缺陷，不改数据格式、不重构功能
- **报告**：`audit/member-manager/REPORT-selfcheck.md`（方法 / 发现 / 结论 / 遗留项）、`audit/member-manager/selfcheck-static.md`（机器输出）

## 修复的缺陷

1. **宿主路由无兜底，内部错误被映射成 400**（`lib/index.js`）
   - `route()` 统一包 `async guarded`：handler 抛错 → `500 {code:"INTERNAL"}` + `bootMark("route-threw:…")` + `routeState.errors`，不向 webServer 抛；
   - `/op` 改 `await fn(...)`，并按 code 分级：`INTERNAL_ERROR`/`INTERNAL` → **500**，业务错误仍 400；
   - `/health` 补 method 校验。
   - 新增 2 例测试：写盘点被占成目录 → 500 `INTERNAL_ERROR`；未知 op 仍 400 `UNKNOWN_OP`。
2. **Esc 会关掉整张表单（丢掉未保存的模型选择）**（`lib/client.js`）
   - 改为优先关子弹层：`picking` → `pickingModel` → 才 `onCancel`；依赖数组补全。
   - 新增测试：注入 `window.addEventListener` 捕获 keydown，断言 Esc 只 `setPicking(false)`。
3. **保存部分成功时不回读**：`saveDraft` 的 catch 里先 `await load()`，界面显示真实名册状态。
4. **空显示名也能点保存**：`canSave = !busy && displayName.trim()`，保存按钮禁用 + `title` 提示；新增文案 `displayNameRequired`（zh/en）。
5. **保存中可用遮罩关窗**：遮罩点击加 `if (busy) return;`。
6. **死代码清理**：删未用文案键 `skills` / `modelPick`、未引用样式 `btnDanger` / `btnOn` / `count` / `row2`，修正过期注释。

## 自检结论

- 单测 **134/134**（原 130 + 新增宿主 2 + 客户端 2；其中 1 例为上一轮按新交互改写）
- 弹窗结构断言 **30/30**（新增：空显示名禁用保存、Esc 优先关弹层、保存中不响应遮罩关闭）
- 静态交叉审计 **61 项：PASS 58 / WARN 3 / FAIL 0**
  - 新增审计脚本 `audit/member-manager/audit-static.mjs`：编码/BOM/LF、i18n 中英键集与重复键、`t()` 键定义对账、`S.*`/`U.*` 引用完整性、死函数、hook 条件调用、客户端 op ↔ 宿主 `OPERATIONS`、`state.*` 视图字段、危险 API、路由表、补丁一致性
  - 3 个 WARN 均非缺陷：`renameGroup` 宿主有 op 但面板无入口（功能缺口）、`docs/00~07` 未随 UI 更新、HTTP 路由依赖 DSH 会话鉴权
- 覆盖契约 **6/6**（`MM_PLUGIN_INDEX` 指向安装版 `lib/index.js`）
- 补丁重生成并校验：
  - `member-manager-client-modal.patch` → **23 hunk / +692 −165**，与安装文件逐字一致
  - `member-manager-0.1.1-local.patch`（宿主）→ **10 hunk / +111 −17**，与安装文件逐字一致
- 安装文件：`lib/client.js` 66,694 B / `A52BD1A4…`；`lib/index.js` 55,240 B / `3FE2FDB9…`
- `audit/patched/` 已同步（lib/client.js、lib/index.js、test/client-bundle.test.mjs、test/host-plugin.test.mjs）

**客户端与宿主均有变更，需重启 DSH 后生效。**

**客户端 bundle 变更需重启 DSH 后重新打开成员编辑弹窗生效。**

---

# 追加变更：按版本归档（v0.1.2，2026-10-19）

把「当前安装状态」整理成可上传、可拷贝到另一台电脑的版本化归档。

## 命名变更（0.1.2 起补丁/产物都带版本号）

| 旧名 | 新名 | 说明 |
|---|---|---|
| `member-manager-client-modal.patch` | `dsh-plugin-member-manager/v0.1.2/patches/member-manager-client-modal-0.1.2.patch` | 客户端补丁（23 hunk / +692 −165） |
| `member-manager-0.1.1-local.patch` | `dsh-plugin-member-manager/v0.1.2/patches/member-manager-index-0.1.2.patch` | 宿主补丁（10 hunk / +111 −17），原名里的版本已过期 |
| `member-manager-index.patched.js` | `dsh-plugin-member-manager/v0.1.2/patches/member-manager-index-0.1.2.patched.js` | 宿主打补丁后的整文件快照 |
| `patches/CHANGES-member-manager.md` | `docs/CHANGES-member-manager.md` | 累计变更记录移出打包目录，作为长期文档 |
| — | `dsh-plugin-member-manager/v0.1.2/artifacts/dsh-plugin-member-manager-0.1.2.{tgz,zip}` | 打包产物（pnpm pack / tar -a） |

> 本文档上方 0.1.1 / 0.1.2 各节的补丁文件名是当时状态；**新路径以本表为准**。`audit-static.mjs` 里的补丁路径已改为按 `package.json` 版本去 `dsh-plugin-member-manager/v<ver>/patches/` 下取。

## 归档结构：单一根目录 + 版本子目录

工作区根只保留 `audit/`（验证与基线）、`docs/`（文档）、`dsh-plugin-member-manager/`（唯一打包根）。
原来的 `dist/`、`patches/` 两个根目录**已删除**——产物与补丁只有一份，直接在版本目录里。

```
dsh-plugin-member-manager/
├── README.md                     归档索引（版本表 + 目录约定 + 重建命令 + 可复现性）
├── SHA256SUMS.txt                归档级校验和（各版压缩包 / 基线 tgz）
├── v0.1.2-archive.zip            整个 v0.1.2/ 的压缩包
├── v0.1.1/                       上游基线：npm 原始 tarball（sha1 与 registry 一致）
│   ├── README.md  ├── SHA256SUMS.txt  └── artifacts/dsh-plugin-member-manager-0.1.1.tgz
└── v0.1.2/
    ├── README.md                 版本总览（脚本生成）
    ├── INSTALL-0.1.2.md          安装 / 离线更新 / 上传发布 / 回滚（人工维护）
    ├── RELEASE-NOTES-0.1.2.md    发布说明（人工维护）
    ├── VERIFICATION-0.1.2.md     全面自检报告
    ├── VERIFICATION-static-0.1.2.md
    ├── SHA256SUMS-0.1.2.txt      本目录全部文件校验和
    ├── artifacts/                tgz / zip / MANIFEST / 产物校验和
    └── patches/                  两个 lib 补丁 + 整文件快照 + 本文档副本
```

## 新增脚本（单命令发布）

- `audit/member-manager/release.mjs <pluginDir> <pristineDir> <releasesRoot> [auditDir]`：一条命令完成
  `pnpm pack` → 解包生成 zip（根目录为包名；内置确定性 zip 打包器：固定 DOS 时间戳 / level 9 / UTF-8 标志 / 按路径排序，**zip 可复现**）→ MANIFEST →
  基于 `pristine/` 重新生成两个补丁 + 宿主整文件快照 → 同步 CHANGES / 验证报告 → 版本 README → 整版压缩包 → 归档级校验和。
- `audit/member-manager/make-diff.mjs`：补丁生成（被 release.mjs 调用）。
- 已删除：`make-dist.mjs`、`archive-release.mjs`（其职责并入 `release.mjs`，避免两套脚本路径漂移）。
- `make-dist.mjs` 早期手写 ustar tar 实现已弃用：中文文件名会让 bsdtar 报 `Invalid empty pathname`，改用 `pnpm pack`。

## 本版归档的验证

- 0.1.1 基线 tarball：SHA1 `3de1c30a…` 与 npm registry `dist.shasum` 一致；解包后与 `audit/member-manager/pristine/` **24 个文件逐字节一致**。
- 0.1.2 tarball：解包后 24 个 entry，**包内自测 134/134 通过**；`lib/client.js`、`lib/index.js` 与安装目录逐字节一致。
- 0.1.2 zip：根目录为 `dsh-plugin-member-manager/`，解压即用；两次独立重建哈希一致（`8427238a…`）。
- 两个补丁在 0.1.1 基线上重放：与当前安装文件逐字一致（`apply-patch-check.mjs`）。
- `dsh-plugin-member-manager/v0.1.2/SHA256SUMS-0.1.2.txt`：13 个文件全部匹配；`dsh-plugin-member-manager/v0.1.2/artifacts/SHA256SUMS.txt`：3 个产物匹配；`dsh-plugin-member-manager/SHA256SUMS.txt`：archive zip 与 0.1.1 基线 tgz 匹配。
