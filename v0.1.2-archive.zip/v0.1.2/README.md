# dsh-plugin-member-manager v0.1.2 · 版本归档

> 由 `audit/member-manager/release.mjs` 生成；`artifacts/`、`patches/`、`README.md`、`SHA256SUMS` 可被重建，**INSTALL / RELEASE-NOTES 为人工维护**。

| 项 | 值 |
|---|---|
| 版本 | `0.1.2` |
| 归档日期 | 2026-10-19（重建时更新） |
| 基线 | npm `0.1.1`（见 `../v0.1.1/`） |
| 状态 | 已在本机安装并通过全量验证；npm registry latest 仍为 0.1.1（本版待发布） |
| 运行时 | DSH desktop profile / `0.2.0-rc.2`，Node >= 22.19 |
| 依赖 | 无 `dependencies` / `peerDependencies` |

## 目录内容

| 路径 | 说明 | 大小 |
|---|---|---|
| `artifacts/dsh-plugin-member-manager-0.1.2.tgz` | npm 兼容 tarball（根 `package/`），发布或普通 npm 项目安装 | 166,762 B |
| `artifacts/dsh-plugin-member-manager-0.1.2.zip` | 解压即得 `dsh-plugin-member-manager/`，用于另一台电脑离线更新 | 185,023 B |
| `artifacts/MANIFEST-0.1.2.txt` | 包内 24 个文件逐个 sha256 | 2,402 B |
| `artifacts/SHA256SUMS.txt` | 上面三个产物的校验和 | — |
| `patches/member-manager-client-modal-0.1.2.patch` | 客户端 `lib/client.js` 补丁（相对 npm 0.1.1） | — |
| `patches/member-manager-index-0.1.2.patch` | 宿主 `lib/index.js` 补丁 | — |
| `patches/member-manager-index-0.1.2.patched.js` | 宿主打补丁后的整文件快照 | — |
| `patches/CHANGES-member-manager.md` | 累计变更记录（源自 `docs/CHANGES-member-manager.md`） | — |
| `INSTALL-0.1.2.md` | 安装 / 离线更新 / 上传 / 回滚 | — |
| `RELEASE-NOTES-0.1.2.md` | 发布说明（可直接贴 GitHub Release） | — |
| `VERIFICATION-0.1.2.md` | 全面自检报告（源自 `audit/member-manager/`） | — |
| `VERIFICATION-static-0.1.2.md` | 静态交叉审计原始输出 | — |
| `SHA256SUMS-0.1.2.txt` | 本目录全部文件校验和 | — |

## 包内关键文件校验

| 文件 | 大小 | SHA256 |
|---|---|---|
| `lib/client.js` | 66,694 B | `a52bd1a427a6d9a3abcc92a1898a0d7b512e2fd5eb2664ea3ddab1c9fda29dcb` |
| `lib/index.js` | 55,240 B | `3fe2fdb971fccb2ff9a518f4b2f8e74b14710d215bf03cb14535e1061d6c0798` |

## 验证矩阵（本版实测）

| 项 | 结果 |
|---|---|
| 单元 / 集成测试 | 134/134 |
| 弹窗结构断言（真实渲染 EditForm） | 30/30 |
| 静态交叉审计 | 61 项：PASS 58 / WARN 3 / FAIL 0 |
| 模型覆盖契约测试 | 6/6 |
| 补丁在 npm 0.1.1 基线上重放 | 与安装文件逐字一致 |
| tarball 解包后自测 | 134/134 |

## 安装与回滚

见 `INSTALL-0.1.2.md`。要点：覆盖 profile 的 `node_modules/dsh-plugin-member-manager`（先确认真实目录还是 Junction）→ **完全退出并重启 DSH** → 用 `boot.log` 的 `apply-completed:tools=12 routes=6` 验证。数据文件 `~/.dsh/storages/member-manager/registry.json` 格式未变。

## 重建

```powershell
$node='C:\Users\rache\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe'
$w='C:\Users\rache\Documents\deepseek-harness\default-workspace'
$inst="$env:USERPROFILE\.dsh\profiles\desktop\node_modules\dsh-plugin-member-manager"
& $node "$w\audit\member-manager\release.mjs" $inst "$w\audit\member-manager\pristine" "$w\dsh-plugin-member-manager" "$w\audit\member-manager"
```
